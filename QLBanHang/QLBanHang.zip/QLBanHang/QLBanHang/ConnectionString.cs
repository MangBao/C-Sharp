﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLBanHang
{
    class ConnectionString 
    {
        public static string connectionString = @"Data Source=DESKTOP-5QGOTHH\SQLEXPRESS;Initial Catalog=QL_BanSach_NT;Integrated Security=True";
    }
}
